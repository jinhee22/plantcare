<?php
$con = mysqli_connect("ip","user","pw","db");
$userEmail = $_POST["m_email"];
$statement = mysqli_prepare($con, "SELECT m_email FROM user WHERE
m_email = ?");  
mysqli_stmt_bind_param($statement, "s", $userEmail);  
mysqli_stmt_execute($statement);  
mysqli_stmt_store_result($statement);  
mysqli_stmt_bind_result($statement, $userEmail);
$response = array();
$response["success"] = true; 
while(mysqli_stmt_fetch($statement)){
$response["success"]=false;
$response["userEmail"]=$userEmail;
}
echo json_encode($response);  mysqli_close($con);
?>
