<?php
    $con = mysqli_connect("ip","user","pw","db");
    mysqli_query($con,'SET NAMES utf8');

    $m_email = $_POST["m_email"];
    $m_pw = $_POST["m_pw"];
    
    
    $statement = mysqli_prepare($con, "SELECT * FROM user WHERE m_email = ? AND m_pw = ?");
    mysqli_stmt_bind_param($statement, "ss", $m_email, $m_pw);
    mysqli_stmt_execute($statement);


    mysqli_stmt_store_result($statement);
    mysqli_stmt_bind_result($statement, $m_email, $m_pw, $m_name);

    $response = array();
    $response["success"] = false;
    
    while(mysqli_stmt_fetch($statement)) {
        $response["success"] = true;
        $response["m_email"] = $m_email;
        $response["m_pw"] = $m_pw;
        $response["m_name"] = $m_name;
    }

    echo json_encode($response);

?>