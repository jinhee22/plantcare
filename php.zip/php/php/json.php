<?php
$con=mysqli_connect("ip","user","pw","db");
if (mysqli_connect_errno()) {
echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
$sql = "SELECT * FROM test1";
if ($result = mysqli_query($con, $sql)) {
$resultArray = array();
$tempArray = array();
$soilArray = array();
$uvArray = array();
while($row = $result->fetch_object()) {
$tempArray = $row;
$soilArray = $row;
$uvArray = $row;
array_push($resultArray, $tempArray, $soilArray, $uvArray);
}
echo json_encode($resultArray);
}
mysqli_close($con);
?>