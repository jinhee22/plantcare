<?php
$con = mysqli_connect("localhost", "root", "defacto8*", "test");  
mysqli_query($con,'SET NAMES utf8');

$userEmail = $_POST["m_email"];
$userPw = $_POST["m_pw"];
$userName = $_POST["m_name"];

$statement = mysqli_prepare($con, "INSERT INTO user VALUES (?,?,?)");  
mysqli_stmt_bind_param($statement, "sss", $userEmail, $userPw, $userName);  
mysqli_stmt_execute($statement);
$response = array();
$response["success"] = true;  
echo json_encode($response);  
mysqli_close($con);
?>
