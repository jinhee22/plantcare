<?php
$con = mysqli_connect("db-82rkr.pub-cdb.ntruss.com", "plant", "12345678!a", "plantdb");  
mysqli_query($con,'SET NAMES utf8');

$dataname = $_POST["dataname"];

$statement = mysqli_prepare($con, "INSERT INTO dataname VALUES (?)");  
mysqli_stmt_bind_param($statement, "s", $dataname);  
mysqli_stmt_execute($statement);
$response = array();
$response["success"] = true;  
echo json_encode($response);  
mysqli_close($con);
?>
