package com.jinhee.login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.view.View;
import android.webkit.WebView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends AppCompatActivity {
    //ArrayList<HashMap<String, String>>
    private ListView mListView;
            private ArrayList<String> mArrayList;
           private ArrayAdapter<String> mArrayAdapter;
    String urlPath = "http://ip주소/json.php";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        WebView wv = findViewById(R.id.wv);
        ListView listView = findViewById(R.id.result);
            DownloadJSON task = new DownloadJSON(MainActivity.this, urlPath, listView);
            task.execute();
        ListView mlistView = findViewById(R.id.result);
        mArrayList = new ArrayList<String>();//List 저장할 array

        Button btnweather = findViewById(R.id.btnweather);
        btnweather.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, weather.class);
                startActivity(intent);
            }
        });


    }
}
