package com.jinhee.login;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class weather extends AppCompatActivity {
    WebView wv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);

        wv = findViewById(R.id.wv);
        wv.loadUrl("https://www.weather.go.kr/w/weather/forecast/mid-term.do");
    }
}
