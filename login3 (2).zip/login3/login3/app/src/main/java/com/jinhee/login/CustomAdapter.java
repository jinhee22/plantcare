package com.jinhee.login;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CustomAdapter extends ArrayAdapter<CustomData> {
    LayoutInflater inflater;
    CustomAdapter(Context context, int resource, List<CustomData> objects) {
        super(context, resource, objects);
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        CustomData item = getItem(position);
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.list_item, null);
        }
        TextView textView1 = convertView.findViewById(R.id.text1);
        textView1.setText(item.getText1Data());
        TextView textView2 = convertView.findViewById(R.id.text2);
        textView2.setText(item.getText2Data());
        TextView textView3 = convertView.findViewById(R.id.text3);
        textView3.setText(item.getText3Data());
        TextView textView4 = convertView.findViewById(R.id.text4);
        textView4.setText(item.getText4Data());
        return convertView;
    }
}