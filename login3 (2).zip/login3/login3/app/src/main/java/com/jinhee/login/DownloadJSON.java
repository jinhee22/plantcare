package com.jinhee.login;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class DownloadJSON extends AsyncTask<Void, Void, String> {
    Context context;
    private String urlPath;
    private ListView listView;
    public DownloadJSON(Context context, String urlPath, ListView listView){
        this.context = context;
        this.urlPath = urlPath;
        this.listView=listView;
    }
    @Override
    protected String doInBackground(Void... voids) {
        try {
            URL url = new URL(urlPath);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setReadTimeout(5000);
            con.setConnectTimeout(5000);
            StringBuilder sb = new StringBuilder();
            try (BufferedReader bufferedReader = new BufferedReader(
                    new InputStreamReader(con.getInputStream()))) {
                String json;
                while ((json = bufferedReader.readLine()) != null) {
                    sb.append(json + "\n");
                }
            }
            return sb.toString().trim();
        } catch (Exception e) {
            return null;
        }    }
        @Override
        protected void onPostExecute(String s) {
        super.onPostExecute(s);
        try {
            loadIntoListView(s);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    private void loadIntoListView(String s) throws JSONException {
        JSONArray jsonArray = new JSONArray(s);
        String[] stocks = new String[jsonArray.length()];
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject obj = jsonArray.getJSONObject(i);
            stocks[i] = "날짜 : " + String.format("%s \n\n", obj.getString("input_time"))
                    + "온도 : " + String.format("%s \n\n", obj.getInt("temp"))
                    + "습도 : " + String.format("%s \n\n", obj.getInt("humidity"))
                    + "토양 습도 : " + String.format("%s \n\n", obj.getString("soil"))
                    + "UV : " + String.format("%s\n", obj.getInt("uv"));

        }
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(context,
                android.R.layout.simple_list_item_1, stocks);
        listView.setAdapter(arrayAdapter);
    }

}