package com.jinhee.login;

public class CustomData {
    private String text1Data;
    private String text2Data;
    private String text3Data;
    private String text4Data;
    private String text5Data;
    private String text6Data;

    public CustomData(){
    }
    public void setText1Data(String text1Data) {
           this.text1Data = text1Data;
    }
    public void setText2Data(String text2Data) {
        this.text2Data = text2Data;
    }

    public String getText1Data() {return text1Data;}
    public String getText2Data() {return text2Data;}
    public String getText3Data() {return text3Data;}
    public String getText4Data() {return text4Data;}
    public String getText5Data() {return text5Data;}
    public String getText6Data() {return text6Data;}

    public void setText3Data(String text3Data) {this.text3Data = text3Data;}
    public void setText4Data(String text4Data) { this.text4Data = text4Data; }
    public void setText5Data(String text5Data){ this.text5Data = text5Data;}
    public void setText6Data(String text6Data) { this.text4Data = text6Data; }
}
